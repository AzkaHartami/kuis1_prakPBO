/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package kuis1;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Main {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        int pil, usia;
        double esai, teknik, design;
        double struktur, data, problem;
        String nama;
        System.out.println("--------------------------------------------");
        System.out.println("|             PROGRAM BEASISWA             |");
        System.out.println("--------------------------------------------");
        System.out.println("| Pilih Beasiswa yang akan diambil         |");
        System.out.println("| 1. Beasiswa Pelajar                      |");
        System.out.println("| 1. Beasiswa Mahasiswa                    |");
        System.out.println("--------------------------------------------");
        System.out.print("Pilihan kategori : ");
        pil = input.nextInt();
        
        if (pil == 1) {
            System.out.println(" --- Form Pendaftaran --- ");
            System.out.print("Masukan Nama   : ");
            nama = input.next();
            
            System.out.print("Usia           : ");
            usia = input.nextInt();
                
                if (usia < 16 || usia > 24){System.out.println("MAAF UMUR ANDA TIDAK SESUAI DENGAN SYARAT YANG BERLAKU");System.exit(0);}
            do {
                System.out.println(" --- Form Penilaian --- ");
                System.out.println("Ket: Nilai dari 1-100");
                System.out.print("Nilai Struktur dan Konten Esai   : ");
                esai = input.nextDouble();
                System.out.print("Nilai Teknik Visualisasi        : ");
                teknik = input.nextDouble();
                System.out.print("Nilai Kemampuan Design Thinking   : ");
                design = input.nextDouble();
                
            } while (esai > 100 || esai < 0 || teknik > 100 || teknik < 0 || design < 0 || design > 100 );
            do {
                System.out.println(" --  Menu  -- ");
                System.out.println(" 1. Tampil ");
                System.out.println(" 2. Edit   ");
                System.out.println(" 3. Exit   ");
                System.out.print("menu : ");
                pil = input.nextInt();
                if (pil == 1) {
                    double hasil;
                    HitungPelajar pa;
                    pa = new HitungPelajar (esai,teknik,design);
                    hasil = pa.hasil();
                    System.out.println("Nilai Akhir : " + hasil);
                    if (hasil < 87.5 ) {
                        System.out.println("Keterangan : GAGAL");
                        System.out.println("MOHON MAAF " + nama +   " TIDAK LULUS seleksi BEASISWA PELAJAR!");
                    }
                    else if (hasil >= 87.5) {
                        System.out.println("Keterangan : BERHASIL");
                        System.out.println("SELAMAT! " + nama +  "  LULUS seleksi BEASISWA PELAJAR!");
                    }
                }
                else if (pil == 2) {
                    do {
                        System.out.println(" --- Form Penilaian --- ");
                        System.out.println("Ket: Nilai dari 1-100");
                        System.out.print("Nilai Struktur dan Konten Esai               : ");
                        esai = input.nextDouble();
                        System.out.print("Nilai Teknik Visualisasi                     : ");
                        teknik = input.nextDouble();
                        System.out.print("Nilai Kemampuan Kemampuan DEsign Thinking    : ");
                        design = input.nextDouble();
                        
                    } while (esai > 100 || esai < 0 || teknik > 100 || teknik < 0 || design < 0 || design > 100 );
                }
            } while (pil != 3);
            
        }
        
        else if (pil == 2) {
            System.out.println(" --- Form Pendaftaran --- ");
            System.out.print("Masukan Nama   : ");
            nama = input.nextLine();
            
            System.out.print("Usia           : ");
            usia = input.nextInt();
            if (usia < 16 || usia > 24){System.out.println("MAAF UMUR ANDA TIDAK SESUAI DENGAN SYARAT YANG BERLAKU");System.exit(0);}
            do {
                 System.out.println(" --- Form Penilaian --- ");
                System.out.println("Ket: Nilai dari 1-100");
                System.out.print("Nilai Struktur dan Konten Jurnal   : ");
                struktur = input.nextDouble();
                System.out.print("Nilai Relevansi Data               : ");
                data = input.nextDouble();
                System.out.print("Nilai Kemampuan Problem Solving    : ");
                problem = input.nextDouble();
            } while (struktur > 100 || struktur < 0 || data > 100 || data < 0 ||  problem > 100 || problem < 0 );
            
             do {
                System.out.println(" --  Menu  -- ");
                System.out.println(" 1. Tampil ");
                System.out.println(" 2. Edit   ");
                System.out.println(" 3. Exit   ");
                System.out.print("menu : ");
                pil = input.nextInt();
                if (pil == 1) {
                    double hasil;
                    HitungMahasiswa ps;
                    ps = new HitungMahasiswa (struktur,data,problem);
                    hasil = ps.hasil();
                    System.out.println("Nilai Akhir : " + hasil);
                    if (hasil < 85) {
                        System.out.println("Keterangan : GAGAL");
                        System.out.println("MOHON MAAF " + nama +  " TIDAK LULUS seleksi BEASISWA PELAJAR!");
                    }
                    else if (hasil >= 85) {
                        System.out.println("Keterangan : BERHASIL");
                        System.out.println("SELAMAT! " + nama +  " LULUS seleksi BEASISWA PELAJAR!");
                    }
                }
                else if (pil == 2) {
                    do {
                       
                        System.out.println(" --- Form Penilaian --- ");
                        System.out.println("Ket: Nilai dari 1-100");
                        System.out.print("Nilai Struktur dan Konten Jurnal               : ");
                        esai = input.nextDouble();
                        System.out.print("Nilai Relevansi Data                           : ");
                        teknik = input.nextDouble();
                        System.out.print("Nilai Kemampuan  Problem Solving               : ");
                        design = input.nextDouble();
                    } while (struktur > 100 || struktur < 0 || data > 100 || data < 0 ||  problem > 100 || problem < 0 );
                 }
             }while (pil != 3);
        }
    }
}
