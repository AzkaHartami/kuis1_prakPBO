/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuis1;
import beasiswa.pelajar;
/**
 *
 * @author ASUS
 */
public class HitungPelajar implements pelajar {
    double a,k,anim,s;
    String keterangan;
    double hasil;
    
    public HitungPelajar(double esai, double teknik, double design) {
        this.a = esai;
        this.k = teknik;
        this.anim = design;

    }
    
     @Override
    public double esai() {
        a = a*0.5;
        return a;
    }

    @Override
    public double teknik() {
        k = k*0.2;
        return k;
    }

    @Override
    public double design() {
        anim = anim*0.3;
        return anim;
    }

   

    @Override
    public double hasil() {
        hasil = esai()+ teknik()+ design();
        return hasil;
    }   
    
 
}
