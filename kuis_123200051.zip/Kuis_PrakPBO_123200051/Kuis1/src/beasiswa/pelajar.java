/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package beasiswa;

/**
 *
 * @author ASUS
 */
public interface pelajar {
    double esai();
    double teknik();
    double design();
    double hasil();
}
