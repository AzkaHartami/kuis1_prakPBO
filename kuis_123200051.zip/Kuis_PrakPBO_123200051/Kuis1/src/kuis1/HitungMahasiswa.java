/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kuis1;
import beasiswa.mahasiswa;
/**
 *
 * @author ASUS
 */
public class HitungMahasiswa implements mahasiswa {
    double struktur, data, problem;
    double hasil;
    public HitungMahasiswa (double struktur, double data, double problem) {
        this.struktur = struktur;
        this.data = data;
        this.problem = problem;

    }
    
    @Override
    public double struktur() {
        struktur = (struktur*60)/100;
        return struktur;
    }

    @Override
    public double data() {
        data = (data*25)/100;
        return data;
    }

    @Override
    public double problem() {
        problem = (problem*15)/100;
        return problem;
    }

    

    public double hasil() {
        hasil = struktur() + data() + problem() ;
        return hasil;
    }
    
}
